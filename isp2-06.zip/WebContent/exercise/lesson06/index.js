function calculate() {
	var input1Element = /* */;
	var input2Element = /* */;
	
	var input1 = parseInt(/* */);
	var input2 = parseInt(/* */);
	var output = /* */;
	
	var outputElement = /* */;
	/* */;
}

window.addEventListener("load", function() {
	var calculateButtonElement = /* */;
	/* */;
}, false);
