window.addEventListener("load", function() {
}, false);