window.addEventListener("load", function () {
    document.write("Hello, world!");
}, false);